<?php
$server_name="localhost";
$user_name="root";
$password="";
$db_name="dpp";

$con= mysqli_connect($server_name,$user_name,$password,$db_name);
?>