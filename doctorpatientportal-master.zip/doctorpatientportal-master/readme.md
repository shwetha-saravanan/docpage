

<h1 align="center"><font color="red"><i>Doctor Patient Portal In CorePHP</i></font><br>


### :pencil: About Project :

**Doctor Patient Portal is a basic portal which helps those patients who stand in line for hours to take appointments with doctor in clinic or hospitals. This portal help to reduce lines in hospital. a simple registration which is free and with lifetime membership for both doctor and patient. Verified doctors with good reputation make our portal more trusty. We provide free services like their own dashboard to manage appointments, and other things.**

<hr>

### :boom: Features :

- ***Login/Register***

- ***Admin Panel***

- ***Create appointments/ delete appointments***

- ***More you find yourselft*** :wink:

<hr>

### :paperclip: Made From :


- [x] ***HTML 5 and CSS 3***

- [x] ***CorePHP***

- [x] ***MYSQL***

- [x] ***Ajax***

- [x] ***Javascript***

<hr>

### :hash: Config

**If you clone this project than in your phpmyadmin make _dpp_ name empty database and import that sqlfile/dpp.sql file in empty database**

>***Default admin password is : <br/>
 email :admin@test.com <br>
 password: 123456***

**Contributors :**

@AnupamAyank (For functionality testing ).
